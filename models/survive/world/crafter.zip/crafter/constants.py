import pathlib,json
root=pathlib.Path(__file__).parent
globals().update(json.loads((root/"data.json").read_text()))
